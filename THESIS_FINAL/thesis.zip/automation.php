
<!DOCTYPE html>
<html>

<html>
   
<!-- LINKS -->
		<link rel="stylesheet" type="text/css" href="style.css">
		<link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
		<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
		<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Raleway">
		<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
		<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Oswald">
		<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Open Sans">
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

<head>
    <meta http-equiv="refresh" content="10">
	<title></title>

	<style type="text/css">
		table
		{
			border-collapse: collapse;
			width: 100%;
			color: #1f5380;
			font-family: monospace;
			font-size: 25px;
			text-align: center;

		}
		th 
		{
			background-color: rgb(47,45,47);;
			color: white;
		}
		tr:nth-child(even) {background-color: #f2f2f2}
</style>
     
</head>
<h4 class="w3-xxlarge w3-center">

			<b>Automation Control</b>

		</h4>
<div class="container w3-center">

		<h4 class="w3-xxlarge w3-center">

	
		</h4>
			
  			<div class="w3-padding w3-hover-opacity-on">

	    		
	    		<a href="dashboard.php" style="width:10%" class="w3-button"><button style="background-color: rgb(240,240,240)">DATA</button>
	    		</a>
	    		<a href="connection.php" style="width:20%" class="w3-button"><button style="background-color: rgb(240,240,240)">CONNECTION</button>
	    		</a>
	    		<a href="graph.php" style="width:20%" class="w3-button"><button style="background-color: rgb(240,240,240)">GRAPH</button>
	    		</a>
	    		<a href="logout.php" style="width:10%" class="w3-button"><button style="background-color: rgb(240,240,240)">LOGOUT</button>
	    		</a>

  			</div>
	</div>
<body>
	<table>

		<?php
		require 'automationcrud.php'; 
		if(isset($_SESSION['message'])): ?>

	<div class="alert alert-<?=$_SESSION['msg_type']?>">
		<?php
		echo $_SESSION['message'];
		unset($_SESSION['message']);
		?>
	</div>
<?php endif ?>
<?php

// $hostt = "localhost";
// $userr = "id12735165_test123";
// $passs = "testroot";
// $dbname = "id12735165_test";
// $dbport = "3306";
// $dbnames = "mysql";

$hostt = "localhost";
$userr = "u678040556_richganguser";
$passs = "richgangroot";
$dbname = "u678040556_richgangdb";
$dbport = "3306";
$dbnames = "mysql";

// $hostt = "127.0.0.1";
// $userr = "root";
// $passs = "";
// $dbname = "automfinal";
// $dbport = "3306";
// $dbnames = "mysql";

	$mysqli = new mysqli($hostt, $userr, $passs, $dbname) or die(mysqlie_error($mysqli));

	$result = $mysqli->query("SELECT * FROM automfin LIMIT 6");
		//pre_r($result);

	?>



	<div class="row justify-content-center">
		<table class="table">
			<thead>
				<tr>
					<th>Id</th>
					<th>Parameter</th>
					<th>Threshold High</th>
					<th>Threshold Low</th>
					<th>Change Threshold High</th>
					<th>Change Threshold Low</th>
				</tr>
			</thead>

<?php 
	
	while ($row = $result->fetch_assoc()): ?>
		<tr>
			<td><?php echo $row['id']; ?></td>
			<td><?php echo $row['parameterfin']; ?></td>
			<td><?php echo $row['threshhigh']; ?></td>
			<td><?php echo $row['threshlow']; ?></td>
			<td>
			    <form action="automationcrud.php" method="POST">
			    <div><a href="automation.php?edit=<?php echo $row['id']; ?>" class="btn btn-info w3-small">CHANGE
				</a>	<button type="submit" class="btn btn-info w3-small" name="update">UPDATE</button></div>
			    
				<input type="hidden" name="id" value="<?php echo $id; ?>">
				<div class="form-group">
				    
			    <input type="number" name="threshhigh" class="form-control" value="<?php echo $threshhigh;?>" placeholder="Enter new threshold">
			    </div>
			</td>
			<td>
			    
			    <div><a href="automation.php?edit=<?php echo $row['id']; ?>" class="btn btn-info w3-small">CHANGE
				</a>	<button type="submit" class="btn btn-info w3-small" name="update">UPDATE</button></div>
			    
				<input type="hidden" name="id" value="<?php echo $id; ?>">
				<div class="form-group">
				    
			    <input type="number" name="threshlow" class="form-control" value="<?php echo $threshlow;?>" placeholder="Enter new threshold">
			    </div>
			</td>
		</tr></form>
	<?php endwhile; ?>
	
	<?php 
	
	while ($row = $result->fetch_assoc()): ?>
		<tr>
			<td><?php echo $row['id']; ?></td>
			<td><?php echo $row['parameterfin']; ?></td>
			<td><?php echo $row['threshhigh']; ?></td>
			<td><?php echo $row['threshlow']; ?></td>
		</tr>
	<?php endwhile; ?>
	
	<?php
		function pre_r($array)
		{
			echo '<pre>';
			print_r($array);
			echo '</pre>';
		}
	?>


</table>
</body>
</html>




