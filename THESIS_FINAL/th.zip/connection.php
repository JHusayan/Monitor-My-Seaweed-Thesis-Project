
<!DOCTYPE html>

<html>
   
<!-- LINKS -->
		<link rel="stylesheet" type="text/css" href="style.css">
		<link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
		<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
		<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Raleway">
		<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
		<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Oswald">
		<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Open Sans">
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

<head>
    <meta http-equiv="refresh" content="5" >
	<title></title>
</head>
<h4 class="w3-xxlarge w3-center">

			<b>Connection</b>

		</h4>
<div class="container w3-center">

		<h4 class="w3-xxlarge w3-center">

	
		</h4>
			
  			<div class="w3-padding w3-hover-opacity-on">

	    		
	    		<a href="dashboard.php" class="w3-button"><button style="background-color: rgb(240,240,240)">DATA</button>
	    		</a>
	    		<a href="automation.php" class="w3-button"><button style="background-color: rgb(240,240,240)">AUTOMATION CONTROL</button>
	    		</a>
	    		<a href="graph.php" class="w3-button"><button style="background-color: rgb(240,240,240)">GRAPH</button>
	    		</a>
	    		<a href="logout.php" class="w3-button"><button style="background-color: rgb(240,240,240)">LOGOUT</button>
	    		</a>

  			</div>
	</div>
<body>




</body>
</html>




