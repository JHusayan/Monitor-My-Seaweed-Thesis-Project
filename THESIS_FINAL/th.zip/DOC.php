<!DOCTYPE html>
<html>
<head>
	<title>
		
	
	<body>
		
	</body>
	</title>
</head>
</html>


// $hostt = "localhost";
// $userr = "id12735165_test123";
// $passs = "testroot";
// $dbname = "id12735165_test";
// $dbport = "3306";
// $dbnames = "mysql";

$hostt = "localhost";
$userr = "id12818541_test123";
$passs = "testroot";
$dbname = "id12818541_test";
$dbport = "3306";
$dbnames = "mysql";


// $hostt = "127.0.0.1";
// $userr = "root";
// $passs = "";
// $dbname = "datafinal";
// $dbport = "3306";
// $dbnames = "mysql";